Yo,

The folder contains the video "Sécurité: dans les coulisses de la cyberdouane - 28/12" [1] with English subtitles (It should play automatically with VLC). The video seems to be a follow-up of the article "INFO BFMTV - Loire: un cyberdealer interpellé, première en France" [2] published couple of days before. Both article and video are from the same French TV channel BFM TV. I skimmed through the article using Google translate and it seems to be accurate enough, but just in case the article mention the arrest of a man for drug trafficking on the "Darknet".

* Lionel G.
* 26 years.
* Ex-legionnaire.
* Operating from a farm near Saint-Germain-la-Montagne [3] in the Loire department (really remote location).
* Selling cannabis, amphetamines and other products.
* Arrested the 14th of December and then released under judicial surveillance and should go to trial the 30th of January.

The French Custom (more or less the equivalent of the custom and border protection) also released a press statement [4] where they confirm they arrested for the first time in France a drug dealer operating on the "Darknet", Silk Road being mentioned. It is said the vendor was arrested the 21 of December whereas BFM TV says the 14th... I would go for the official statement to be more accurate. They also confirm they ordered from the vendor on Silk Road and got a delivery at an anonymous address, which allowed them to confirm the package contained drug and to materialise the "Flagrant Délit" (it is basically a French law/police term to say the guy was caught red-handed, or in the act of breaking the law). Following reception of the package they went to the suspect place where they found drugs and other stuff used to sell online (not sure what they refer to here). At a second visit they arrested an accomplice (a girl).

Using the information provided in the BFM article I went through the Stexo backup of vendors shipping from France and the profile of Walkaboot seems to match.

* Type of product seized at his place and what is advertised on his vendor page [5].
* Googling his name gives result of a profile on some sort of "truck/RV" forum [6].
* Unfortunately for him the information he mentioned on the forum profile matches the one in the article:

    - Name: Walkaboot
    - Location: Loire
    - Age: 26
    - Job: Silk Road
    - Department: 42 (This is the area code of the Loire department).

There is also a facebook [7] profile where he posted on the 30th of December 2013:

"Thanks for everything..really.. don't call me on the other phones, I don't don't have them. I have a Romanian phone, but only for the family. The 30th of January we will be fixed. Thanks if a good soul could record the 20h [8]. WE DON'T HAVE RECORDER, nothing left.. To all an happy new year. This is the end.."

The French version is quite badly written so I kept the meaning but corrected the grammar and spelling mistake in the English translation. He is likely a Romanian citizen who was in the French Foreign Legion [9] if the article of the BFM TV is accurate, which would explain the fact he seems to speak very good French but struggle writing it. Also the article mention the name Lionel G, which sounds really French, but on the forum profile the first name Yakoff & Mado are provided. One of the specificity of the French Foreign Legion is you can be enrolled under your real name or "adoption name" when you receive the French Nationality [10]. Mado is probably the (accomplice).

The 4th of December, also on facebook, he posted an article of the BBC about the re-opening of Silk Road, and basically says that since 2009 and the creation of the Bitcoins the "Techno" community is represented and that he can help if anyone needs but not on facebook... He also recommends the use of Safemail, Torchat and PGP.

I think you can safely add this one on the arrest list.  Feel free to rewrite and use whatever is in the archive.

Let me know if you need anything else.

Peace!

[1] http://youtu.be/mah1k4Fv3rg
[2] http://www.bfmtv.com/societe/info-bfmtv-loire-un-cyberdealer-interpelle-premiere-france-674582.html
[3] http://goo.gl/maps/egFaE
[4] http://www.douane.gouv.fr/page.asp?id=4599
[5] http://antilop.cc/sr/vendors/ce349694a5.htm
[6] http://forum.bernard.debucquoi.com/memberlist.php?mode=viewprofile&u=10324
[7] https://www.facebook.com/BootRokrRider
[8] The 20H is the name given to the daily French TV news at 8pm. I don't know if he refers to the video of BFM TV or another one. I'll check out and let you know.
[9] http://en.wikipedia.org/wiki/French_Foreign_Legion
[10] http://en.wikipedia.org/wiki/French_Foreign_Legion#Membership